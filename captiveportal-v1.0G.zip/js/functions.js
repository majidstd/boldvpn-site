/**
 * BoldVPN Captive Portal - Minimal functions (OPNsense compatibility)
 */

// Stub for any template functions that might be called
